'use strict';

// Default Gulp task is "watch"

var gulp        = require('gulp');

gulp.task('default', ['watch']);






